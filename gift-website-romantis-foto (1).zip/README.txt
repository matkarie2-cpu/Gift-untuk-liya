GIFT WEBSITE ROMANTIS

File utama: index.html

PERSONALISASI:
1. Buka index.html dengan editor teks (misalnya VS Code atau editor kode di HP).
2. Cari const recipient = "Sayang"; lalu ganti nama panggilan.
3. Ganti teks surat di bagian <article class="card letter" id="letter">.
4. Untuk foto: ganti setiap <div class="photo-placeholder">...</div> dengan:
   <img src="images/foto1.jpg" alt="Kenangan kita">
   Buat folder images dan letakkan foto dengan nama yang sesuai.
5. Untuk musik, letakkan file audio milikmu bernama music.mp3 di folder yang sama dengan index.html.
   Gunakan musik yang kamu punya izin untuk digunakan.

PUBLISH GRATIS DENGAN GITHUB PAGES:
1. Buat akun di https://github.com
2. Buat repository baru bernama misalnya gift-untukmu.
3. Upload index.html, music.mp3 (jika ada), dan folder images (jika ada).
4. Buka Settings > Pages.
5. Di Build and deployment, pilih Deploy from a branch.
6. Pilih branch main dan folder /(root), lalu Save.
7. Tunggu beberapa menit. URL website akan tampil di halaman Pages, biasanya:
   https://USERNAME.github.io/gift-untukmu/

Alternatif: Netlify Drop (https://app.netlify.com/drop) dapat digunakan untuk deploy cepat dengan menyeret folder website ke halaman tersebut. Ketersediaan langkah antarmuka bisa berubah.

Catatan: halaman ini bersifat publik jika dipublikasikan dengan GitHub Pages. Jangan memasukkan informasi pribadi atau sensitif.


FOTO KENANGAN SUDAH DITAMBAHKAN:
- images/kenangan-1.jpg = gambar chat (urutan 1)
- images/kenangan-2.jpg = foto berdua (urutan 2)
- images/kenangan-3.jpg = foto close-up (urutan 3)

Saat mengunggah ke GitHub Pages, unggah seluruh folder images beserta index.html.
